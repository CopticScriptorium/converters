'''
Created on Feb 5, 2013

@author: eric
'''

upperToLowerMap = {
    u'A' : u'a',
    u'B' : u'b',
    u'G' : u'g',
    u'D' : u'd',
    u'E' : u'e',
    u'+' : u'=',
    u'Z' : u'z',
    u'H' : u'h',
    u'U' : u'u',
    u'I' : u'i',
    u'K' : u'k',
    u'L' : u'l',
    u'M' : u'm',
    u'N' : u'n',
    u'J' : u'j',
    u'O' : u'o',
    u'P' : u'p',
    u'R' : u'r',
    u'S' : u's',
    u'T' : u't',
    u'Y' : u'y',
    u'F' : u'f',
    u'X' : u'x',
    u'C' : u'c',
    u'V' : u'v',
    u'W' : u'w',
    u'Q' : u'q',
    u'\u00f6' : u'\u00e9',
    u'\u00e4' : u'\u00e0', 
    u'\u00a3' : '!',
    u'\u00fc' : u'\u00e8', 
    u'>' : u'<',
}

UPPERS = upperToLowerMap.keys()

LOWERS = set(upperToLowerMap.itervalues())

# This table is for all the conversions that, when bolded, append a 0323 character
simpleConversionTable = {
    # first, list all of the letters with their upper case pairings.
    u'a' : u'\u2c81',
    u'A' : u'\u2c81\u0304',
    u'b' : u'\u2c83',
    u'B' : u'\u2c83\u0304',
    u'g' : u'\u2c85',
    u'G' : u'\u2c85\u0304',
    u'd' : u'\u2c87',
    u'D' : u'\u2c87\u0304',
    u'e' : u'\u2c89',
    u'E' : u'\u2c89\u0304',
    u'=' : u'\u2c8b',
    u'+' : u'\u2c8b\u0304',
    u'z' : u'\u2c8d',
    u'Z' : u'\u2c8d\u0304',
    u'h' : u'\u2c8f',
    u'H' : u'\u2c8f\u0304',
    u'u' : u'\u2c91',
    u'U' : u'\u2c91\u0304',
    u'i' : u'\u2c93',
    u'I' : u'\u2c93\u0304',
    u'k' : u'\u2c95',
    u'K' : u'\u2c95\u0304',
    u'l' : u'\u2c97',
    u'L' : u'\u2c97\u0304',
    u'm' : u'\u2c99',
    u'M' : u'\u2c99\u0304',
    u'n' : u'\u2c9b',
    u'N' : u'\u2c9b\u0304',
    u'j' : u'\u2c9d',
    u'J' : u'\u2c9d\u0304',
    u'o' : u'\u2c9f',
    u'O' : u'\u2c9f\u0304',
    u'p' : u'\u2ca1',
    u'P' : u'\u2ca1\u0304',
    u'r' : u'\u2ca3',
    u'R' : u'\u2ca3\u0304',
    u's' : u'\u2ca5',
    u'S' : u'\u2ca5\u0304',
    u't' : u'\u2ca7',
    u'T' : u'\u2ca7\u0304',
    u'y' : u'\u2ca9',
    u'Y' : u'\u2ca9\u0304',
    u'f' : u'\u2cab',
    u'F' : u'\u2cab\u0304',
    u'x' : u'\u2cad',
    u'X' : u'\u2cad\u0304',
    u'c' : u'\u2caf',
    u'C' : u'\u2caf\u0304',
    u'v' : u'\u2cb1',
    u'V' : u'\u2cb1\u0304',
    u'w' : u'\u03e5',
    u'W' : u'\u03e5\u0304',
    u'q' : u'\u03ed',
    u'Q' : u'\u03ed\u0304',
    
    u'\u00e7' : u'\u2c93\u0308',
    
    u'\u00e9' : u'\u03e3',
    u'\u00f6' : u'\u03e3\u0304',
    
    u'\u00e0' : u'\u03e9',
    u'\u00e4' : u'\u03e9\u0304',
    
    u'!' : u'\u03e7',
    u'\u00a3' : u'\u03e7\u0304',
    
    u';' : u'\u2cf3',
    u'$' : u'\u2cc9',
    
    u'\u00e8' : u'\u03eb',
    u'\u00fc' : u'\u03eb\u0304',
    
    u'<' : u'\u03ef',
    u'>' : u'\u03ef\u0304',
    
    u'~' : u'\u2cbb',
    u'\u00a9' : u'\u2cd3',
    u'\u00ae' : u'\u2cb9',
    u'\u00b5' : u'\u2cc3',
    u'\u00ba' : u'\u2ccd',
    u'\u00df' : u'\u2cc5',
    u'\u00e6' : u'\u2cb3',
    u'\u00f8' : u'\u2cd1',
    u'\u0192' : u'\u2cd7',
    u'\u03c0' : u'\u2ccf',
    u'\u2202' : u'\u2cd9',
    u'\u2248' : u'\u2ccb',
    u'\u00a7' : u'\u2ce8',
    u'\u00b6' : u'\u2ce5',
    
}

# Entries in this table do not change when bolded.
specialConversionTable = {
    u'\u0023' : u'\u2e33',
    u'\u002c' : u'\u00b7',
    u'\u002f' : u'\u002c',
    u'\u00ad' : u'\u2e34',
    u'\u2026' : u'\u00a0\u0323',
    u'\u2018' : u'\u2cff',
    u'\u005f' : u'\u2e17',
    u'\u005c' : u'\u2016',
    u'\u007b' : u'\u005b',
    u'\u007d' : u'\u005d',
    u'\u0025' : u'\u003c',
    u'\u0026' : u'\u003e',
    u'\u005b' : u'\u007b',
    u'\u005d' : u'\u007d',
    u'\u00d2' : u'\u27e6',
    u'\u00d4' : u'\u27e7',
    u'\u0027' : u'\u0308',
    u'\u003f' : u'\u0302',
    u'\u00bf' : u'\u0302',
    u'\uf000' : u'\u1dcd',
    u'\u00e5' : u'\u0300',
    u'\u222b' : u'\u0301',
    u'\u2122' : u'\u0307',
    u'\u0153' : u'\u0307',
    u'\u03a3' : u'\u0307',
}

noopConversionTable = [
    u'\u002d',
    u'\u002e',
    u'\u0020',
    u'\u00a0',
    u'\u002a',
    u'\u007c',
    u'\u00b1',
    u'\u0028',
    u'\u0029',
    u'\u0030',
    u'\u0031',
    u'\u0032',
    u'\u0033',
    u'\u0034',
    u'\u0035',
    u'\u0036',
    u'\u0037',
    u'\u0038',
    u'\u0039',
    
    # Note that the footnoting in Markdown introduces the "^" for linking to footnotes.
    u'\u005e',
]

# The join characters (2013 & 2014) add a little bit of complexity - to handle it correctly
# we must keep track of which state of the previous two characters The breakdown is as follows -

# "x" stands for any char (lower or upper case, or symbol)
# "A" stands for upper case only
# "a" stands for lower case only
# "?" stands for a character neither upper nor lower
# "-" stands for 2013 or 2014
# eoc  stands for end of a Coptic sequence     

# preceding string:    state:
# ""                   regular char (RC)
# "x"                  regular char (RC)
# "xx"                 regular char (RC)
# "x-"                 char + join  (CJ)
# "-A"                 join + upper char (JUC)
# "-a"                 join + lower char (JLC)
# "-?"                 join + lower char (JLC)

# state:    input:    action:                  new state:
# RC        x         output conv(x)           RC
# RC        -         output FE24              CJ
# RC        eoc       (nothing)                RC
# CJ        -         warn                     CJ
# CJ        A         output conv(tolower(A))  JUC
# CJ        a         output conv(a)           JLC
# CJ        ?         warn, output conv(?)     JLC
# CJ        eoc       warn!                    RC
# JUC       -         output FE26              CJ
# JUC       x         warn! conv(x)            RC
# JUC       eoc       warn!                    RC
# JLC       -         warn, output FE26        CJ
# JLC       x         output conv(x), FE25     RC
# JLC       eoc       FE25                     RC

# note that the "eoc" input is actually captured outside of the conversion method
# because it is triggered by a format change, or the end of the document.

STATE_RC = 0
STATE_CJ = 1
STATE_JUC = 2
STATE_JLC = 3

def convertSingleCharacter(oneChar, isBold):
    outBuf = u"";
    if oneChar in simpleConversionTable:
        outBuf += simpleConversionTable[oneChar]
        
        if isBold:
            outBuf += u'\u0323'
    
    elif oneChar in specialConversionTable:
        if oneChar == u'\u2026':
            pass
        outBuf += specialConversionTable[oneChar]
        if isBold:
            print "Input character " + oneChar + " is unexpectedly bold"
    else:
        if not oneChar in noopConversionTable:
            print "Character {0:x} is unexpectedly not in any conversion table.".format(ord(oneChar[0]))
        outBuf += oneChar
        
    return outBuf

class VanDammeWurstConverter:
    '''
    classdocs
    '''


    def __init__(self):
        # We keep track of the conversion state
        self.CharConversionState = STATE_RC

        '''
        Constructor
        '''
        pass
    
    def emitText(self, node, style):
        return self.convertCopticCharacters(node.nodeValue, style.bold == 1)

    # at least for now, we don't have this conversion do anything, because we're just interested in
    # the text.
    def emitCitation(self, cite):
        return ""
    
    def isStyleMatch(self, style):
        return style.fontName == "Coptic"

    def endSequence(self):
        return self.convertWithState( None, False )

    def handleStyling(self, styleName, style, text):
        """In the case of Coptic conversion, we're not interested in
        preserving the styling - especially bold, which is merely used
        as an indicator for combining characters, in Unicode
        """
        return text

    def wrapParagraph(self, text, indent = 0, blockquote = False) :
        return text

    def convertCopticCharacters(self, text, isBold):
        
        outBuf = "";
        for ch in text:
            outBuf += self.convertWithState(ch, isBold )
        
        # print "from: " + text + "\n  to: " + outBuf
        
        return outBuf    
    

    def convertWithState(self, oneChar, isBold):
        """oneChar may be null, which signifies the end of a coptic string
        """
        
        # The state really should be a parameter to the method, or we should define a class that manages
        # this state.
        
        outBuf = ""
        
        if self.CharConversionState == STATE_RC:
            if not oneChar:
                self.CharConversionState = STATE_RC
            elif oneChar == u'\u2014' or oneChar == u'\u2013':
                outBuf = u'\uFE24'
                self.CharConversionState = STATE_CJ
            else:
                outBuf = convertSingleCharacter(oneChar, isBold)
                self.CharConversionState = STATE_RC
        elif self.CharConversionState == STATE_CJ:
            if not oneChar:
                print u"Unexpected end of a Coptic string after a \\u2014"
                self.CharConversionState = STATE_RC
            elif oneChar == u'\u2014' or oneChar == u'\u2013':
                print u'Unexpected hyphen after another hyphen'
                # stay in the same state
            elif oneChar in UPPERS:
                outBuf = convertSingleCharacter( upperToLowerMap[oneChar], isBold)
                self.CharConversionState = STATE_JUC
            elif oneChar in LOWERS:
                outBuf = convertSingleCharacter( oneChar, isBold )
                self.CharConversionState = STATE_JLC
            else:
                print u'Unexpected character - neither upper nor lower, after a hyphen'
                outBuf = convertSingleCharacter( oneChar, isBold )
        elif self.CharConversionState == STATE_JUC:
            if not oneChar:
                print "After a hyphen and an upper case character, expected to encounter another hyphen, not the end of a coptic string"
                self.CharConversionState = STATE_RC
            elif oneChar == u'\u2014' or oneChar == u'\u2013':
                self.CharConversionState = STATE_CJ
                outBuf = u'\uFE26'
            else:
                print "After a hyphen and an upper case character, expected to encounter another hyphen, not a lower case character"
                self.CharConversionState = STATE_RC
        elif self.CharConversionState == STATE_JLC:
            if not oneChar:
                self.CharConversionState = STATE_RC
                outBuf = u'\uFE25'
            elif oneChar == u'\u2014' or oneChar == u'\u2013':
                print "Found a hyphen after a lower case character, when the previous character should have been an uppercase character"
                self.CharConversionState = STATE_CJ
                outBuf = u'\uFE26'
            else:
                outBuf = u"\ufe25" + convertSingleCharacter( oneChar, isBold )
                self.CharConversionState = STATE_RC
                
        return outBuf
            
