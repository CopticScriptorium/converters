#!/usr/bin/python

## To access this file as plain text please go to
## http://freewisdom.org/projects/python-markdown/odt2txt_py.raw_content
## After downloading save with ".py" extension
## this isn't world editable, is it?
## It is editable :-D
"""
ODT2TXT
=======

ODT2TXT converts files in Open Document Text format (ODT) into
Markdown-formatted plain text.

Written by by [Yuri Takhteyev](http://www.freewisdom.org).

Project website: http://www.freewisdom.org/projects/python-markdown/odt2txt
Contact: yuri [at] freewisdom.org

License: GPL 2 (http://www.gnu.org/copyleft/gpl.html) or BSD

Version: 0.1 (April 7, 2006)
"""

import sys, zipfile, xml.dom.minidom
import VanDammeWurstConverter

IGNORED_TAGS = ["office:annotation"]

FOOTNOTE_STYLES = ["Footnote"]

def effectiveStyle(parentStyle, childStyle):
    newStyle = TextProps()
    newStyle.italic = childStyle.italic
    if childStyle.bold >= 0:
        newStyle.bold = childStyle.bold
    else:
        newStyle.bold = parentStyle.bold
    newStyle.fixed = childStyle.fixed
    newStyle.fontName = childStyle.fontName
    
    return newStyle

class TextProps :
    """ Holds properties for a text style. 
    
    bold value is a three-state value - it can be -1 (not set), 0 (normal), or 1 (bolded)
    """

    def __init__ (self):
        
        self.italic = False
        self.bold = -1
        self.fixed = False
        self.fontName = None

    def setItalic (self, value) :
        if value == "italic" :
            self.italic = True

    def setBoldFromAttr (self, value) :
        if value == "bold" :
            self.bold = 1
        elif value == "normal":
            self.bold = 0

    def setFixed (self, value) :
        self.fixed = value

    def setFontName(self, font):
        self.fontName = font

    def isCopticFont(self):
        return isCopticFontName(self.fontName)
            
    def __str__ (self) :

        return "[i=%s, h=i%s, fixed=%s]" % (str(self.italic),
                                          str(self.bold),
                                          str(self.fixed))

def isCopticFontName(fontName):
    """
    For the moment, this assumes a specific set of font names.
    """
    return fontName == "Coptic"
    
class ParagraphProps :
    """ Holds properties of a paragraph style. """

    def __init__ (self):

        self.blockquote = False
        self.headingLevel = 0
        self.code = False
        self.title = False
        self.fontName = None
        self.indented = 0
        self.bold = -1

    def setIndented (self, value) :
        self.indented = value

    def setHeading (self, level) :
        self.headingLevel = level

    def setTitle (self, value):
        self.title = value

    def setCode (self, value) :
        self.code = value

    def setFontName(self, font):
        self.fontName = font
    
    def setBold(self, bold):
        self.bold = bold
        
    def isCopticFont(self):
        return isCopticFontName(self.fontName)

    def __str__ (self) :

        return "[bq=%s, h=%d, code=%s]" % (str(self.blockquote),
                                           self.headingLevel,
                                           str(self.code))


class ListProperties :
    """ Holds properties for a list style. """

    def __init__ (self):
        self.ordered = False
 
    def setOrdered (self, value) :
        self.ordered = value

class RegularMarkDownEmitter:
    
    def __init__(self):
        pass
    
    def emitText(self, node, style):
        """In the case of markdown format, we simply emit the text.
        """
        # TODO - should this instead escape certain markdown characters?
        return node.nodeValue
    
    def isStyleMatch(self, style):
        # TODO - this should be more general
        return style.fontName != "Coptic"
    
    def emitCitation(self, cite):
        return "[^%s]" % cite

    # Markdown doesn't need to keep state across child nodes.
    def endSequence(self):
        return u""
    
    def handleStyling(self, styleName, style, text):
        strBuf = u""
        if style and style.fixed :
            strBuf += "`" + text + "`"
        elif style :
            if style.italic and style.bold == 1 :
                mark = "***"
            elif style.italic :
                mark = "_"
            elif style.bold == 1 :
                mark = "**"
            else :
                mark = ""
        else :
            mark = "<" + styleName + ">"

        strBuf += "%s%s%s" % (mark, text, mark)
        return strBuf

    def wrapParagraph(self, text, indent = 0, blockquote = False) :

        counter = 0
        strBuf = ""
        LIMIT = 50

        if blockquote :
            strBuf += "> "
        
        for token in text.split() :

            if counter > LIMIT - indent :
                strBuf += "\n" + " "*indent
                if blockquote :
                    strBuf += "> "
                counter = 0

            strBuf += token + " "
            counter += len(token)

        return strBuf


class OpenDocumentTextFile :

    def __init__ (self, filepath) :
        self.footnotes = []
        self.footnoteCounter = 0
        self.textStyles = {"Standard" : TextProps()}
        self.paragraphStyles = {"Standard" : ParagraphProps()}
        self.listStyles = {}
        self.fixedFonts = []
        self.hasTitle = 0

        self.load(filepath)
        

    def processFontDeclarations (self, fontDecl) :
        """ Extracts necessary font information from a font-declaration
            element.
            """
        for fontFace in fontDecl.getElementsByTagName("style:font-face") :
            if fontFace.getAttribute("style:font-pitch") == "fixed" :
                self.fixedFonts.append(fontFace.getAttribute("style:name"))
        


    def extractTextProperties (self, style, parent=None) :
        """ Extracts text properties from a style element. """
        
        textProps = TextProps()
        
        if parent :
            parentProp = self.textStyles.get(parent, None)
            if parentProp :
                textProp = parentProp
            
        textPropEl = style.getElementsByTagName("style:text-properties")
        if not textPropEl : return textProps
        
        textPropEl = textPropEl[0]

        fontName = textPropEl.getAttribute("style:font-name")
        italic = textPropEl.getAttribute("fo:font-style")
        bold = textPropEl.getAttribute("fo:font-weight")

        textProps.setItalic(italic)
        textProps.setBoldFromAttr(bold)
        textProps.setFontName(fontName)

        if textPropEl.getAttribute("style:font-name") in self.fixedFonts :
            textProps.setFixed(True)

        return textProps

    def extractParagraphProperties (self, style, parent=None) :
        """ Extracts paragraph properties from a style element. """

        paraProps = ParagraphProps()

        name = style.getAttribute("style:name")

        if name.startswith("Heading_20_") :
            level = name[11:]
            try :
                level = int(level)
                paraProps.setHeading(level)
            except :
                level = 0

        if name == "Title" :
            paraProps.setTitle(True)
        
        paraPropEl = style.getElementsByTagName("style:paragraph-properties")
        if paraPropEl :
            paraPropEl = paraPropEl[0]
            leftMargin = paraPropEl.getAttribute("fo:margin-left")
            if leftMargin :
                try :
                    leftMargin = float(leftMargin[:-2])
                    if leftMargin > 0.01 :
                        paraProps.setIndented(True)
                except :
                    pass

        textProps = self.extractTextProperties(style)
        if textProps.fixed :
            paraProps.setCode(True)

        # Make sure to copy over the font information to the paragraph style.
        paraProps.setFontName(textProps.fontName)
        
        if textProps.bold:
            paraProps.setBold(textProps.bold)
            
        return paraProps
    

    def processStyles(self, styleElements) :
        """ Runs through "style" elements extracting necessary information.
            """

        for style in styleElements :

            name = style.getAttribute("style:name")

            if name == "Standard" : continue

            family = style.getAttribute("style:family")
            parent = style.getAttribute("style:parent-style-name")

            if family == "text" : 
                self.textStyles[name] = self.extractTextProperties(style,
                                                                   parent)

            elif family == "paragraph":
                self.paragraphStyles[name] = (
                                 self.extractParagraphProperties(style,
                                                                 parent))
    def processListStyles (self, listStyleElements) :

        for style in listStyleElements :
            name = style.getAttribute("style:name")

            prop = ListProperties()
            if style.childNodes :
                if ( style.childNodes[0].tagName
                     == "text:list-level-style-number" ) :
                    prop.setOrdered(True)

            self.listStyles[name] = prop
        

    def load(self, filepath) :
        """ Loads an ODT file. """
        
        zipFile = zipfile.ZipFile(filepath)

        styles_doc = xml.dom.minidom.parseString(zipFile.read("styles.xml"))
        self.processFontDeclarations(styles_doc.getElementsByTagName(
            "office:font-face-decls")[0])
        self.processStyles(styles_doc.getElementsByTagName("style:style"))
        self.processListStyles(styles_doc.getElementsByTagName(
            "text:list-style"))
        
        self.content = xml.dom.minidom.parseString(zipFile.read("content.xml"))
        self.processFontDeclarations(self.content.getElementsByTagName(
            "office:font-face-decls")[0])
        self.processStyles(self.content.getElementsByTagName("style:style"))
        self.processListStyles(self.content.getElementsByTagName(
            "text:list-style"))

    def compressCodeBlocks(self, text) :
        """ Removes extra blank lines from code blocks. """

        lines = text.split("\n")
        strBuf = ""
        numLines = len(lines)
        for i in range(numLines) :
            
            if (lines[i].strip() or i == numLines-1  or i == 0 or
                not ( lines[i-1].startswith("    ")
                      and lines[i+1].startswith("    ") ) ):
                strBuf += "\n" + lines[i]

        return strBuf

    def listToString (self, listElement) :

        strBuf = ""

        styleName = listElement.getAttribute("text:style-name")
        props = self.listStyles.get(styleName, ListProperties())

            
        i = 0
        for item in listElement.childNodes :
            i += 1
            if props.ordered :
                number = str(i)
                number = number + "." + " "*(2-len(number))
                strBuf += number + self.paragraphToString(item.childNodes[0],
                                                        indent=3)
            else :
                strBuf += "* " + self.paragraphToString(item.childNodes[0],
                                                        indent=2)
            strBuf += "\n\n"
            
        return strBuf

    def toString (self) :
        """ Converts the document to a string. """
        body = self.content.getElementsByTagName("office:body")[0]
        text = self.content.getElementsByTagName("office:text")[0]

        strBuf = u""


        paragraphs = [el for el in text.childNodes
                      if el.tagName in ["text:p", "text:h",
                                        "text:list"]]

        for paragraph in paragraphs :
            if paragraph.tagName == "text:list" :
                text = self.listToString(paragraph)
            else :
                text = self.paragraphToString(paragraph)
            if text :
                strBuf += text + "\n\n"

        if self.footnotes :

            strBuf += "--------\n\n"
            for cite, body in self.footnotes :
                strBuf += "[^%s]: %s\n\n" % (cite, body)


        return self.compressCodeBlocks(strBuf)

    def emitterForStyle(self, emitter, style):
        
        # This check makes sure that the emitter is unchanged when the font
        # name is unchanged.
        if emitter and (not style or not style.fontName):
            return emitter
        
        if emitter:
            if emitter.isStyleMatch(style):
                return emitter;
            emitter.endSequence()
        
        if style and style.fontName == "Coptic":
            return VanDammeWurstConverter.VanDammeWurstConverter()
        else:
            return RegularMarkDownEmitter()
        
    def textToString(self, element, parentEmitter, parentStyle) :

        strBuf = u""

        emitter = parentEmitter
        for node in element.childNodes :

            if node.nodeType == xml.dom.Node.TEXT_NODE :
                strBuf += emitter.emitText(node, parentStyle)

            elif node.nodeType == xml.dom.Node.ELEMENT_NODE :
                tag = node.tagName

                if tag == "text:span" :

                    styleName = node.getAttribute("text:style-name")
                    style = self.textStyles.get(styleName, None)

                    # get an emitter for how to handle this node.
                    emitter = self.emitterForStyle(parentEmitter, style)
                    
                    # now get the text of the node.
                    effStyle = effectiveStyle(parentStyle, style)
                    text = self.textToString(node, emitter, effStyle) 

                    # only for non-empty strings do I want to emit anything.
                    if text.strip() :
                        strBuf += emitter.handleStyling(styleName, style, text)
                    
                elif tag == "text:note" :
                    cite = (node.getElementsByTagName("text:note-citation")[0]
                                .childNodes[0].nodeValue)
                               
                    body = (node.getElementsByTagName("text:note-body")[0]
                                .childNodes[0])

                    styleName = body.getAttribute("text:style-name")
                    paragraphStyle = self.paragraphStyles.get(styleName, None)

                    # get an emitter for how to handle this node - but ignore the parent emitter, because it is a footnote.
                    emitter = self.emitterForStyle(None, paragraphStyle)
                    if parentEmitter != emitter:
                        strBuf += parentEmitter.endSequence()

                    self.footnotes.append((cite, self.textToString(body, emitter, paragraphStyle)))

                    strBuf += parentEmitter.emitCitation(cite)

                elif tag in IGNORED_TAGS :
                    pass

                elif tag == "text:s" :
                    try :
                        num = int(node.getAttribute("text:c"))
                        strBuf += " "*num
                    except :
                        strBuf += " "

                elif tag == "text:tab" :
                    strBuf += "    "


                elif tag == "text:a" :

                    text = self.textToString(node, emitter, parentStyle)
                    link = node.getAttribute("xlink:href")
                    strBuf += "[%s](%s)" % (text, link)
                    
                else :
                    strBuf += " {" + tag + "} "

        # Now, check that if we've just emitted a sequence of characters, see whether
        # the parent emitter is different, and if it is, end the sequence.
        if parentEmitter != emitter:
            strBuf += emitter.endSequence()
        return strBuf

    def paragraphToString(self, paragraph, indent = 0) :


        style_name = paragraph.getAttribute("text:style-name")
        paraProps = self.paragraphStyles.get(style_name) #, None)
        emitter = self.emitterForStyle(None, paraProps)
        text = self.textToString(paragraph, emitter, paraProps)
        text += emitter.endSequence()

        #print style_name

        if paraProps and not paraProps.code :
            text = text.strip()

        if paraProps.title :
            self.hasTitle = 1
            return text + "\n" + ("=" * len(text))

        if paraProps.headingLevel :

            level = paraProps.headingLevel
            if self.hasTitle : level += 1

            if level == 1 :
                return text + "\n" + ("=" * len(text))
            elif level == 2 :
                return text + "\n" + ("-" * len(text))
            else :
                return "#" * level + " " + text

        elif paraProps.code :
            lines = ["    %s" % line for line in text.split("\n")]
            return "\n".join(lines)

        if paraProps.indented :
            return emitter.wrapParagraph(text, indent = indent, blockquote = True)

        else :
            return emitter.wrapParagraph(text, indent = indent)
        


if __name__ == "__main__" :
    
    odt = OpenDocumentTextFile(sys.argv[1])

    outputFile = None
    if len(sys.argv) > 2:
        outputFile = sys.argv[2]
    
    #print odt.fixedFonts

    #sys.exit(0)
    #out = open("out.txt", "wb")

    unicodeContent = odt.toString()
    out_utf8 = unicodeContent.encode("utf-8")

    # Either output to a file, or to the console
    if outputFile:
        with open(outputFile, "w") as f:
            f.write(out_utf8)
    else:
        sys.stdout.write(out_utf8)
